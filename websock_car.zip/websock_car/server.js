const express = require('express');
const http = require('http');
const WebSocket = require('ws');

// App y servidor HTTP
const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Carpeta pública para HTML
app.use(express.static('public'));

// Stock inicial del producto
let stock = 5;

// WebSocket conexión
wss.on('connection', (ws) => {
    // Enviar stock actual al cliente que se conecta
    ws.send(JSON.stringify({ type: 'stock', value: stock }));

    ws.on('message', (message) => {
        const data = JSON.parse(message);

        if (data.type === 'add_to_cart' && stock > 0) {
            stock--; // Resta del stock

            // Notificar a todos los clientes conectados
            wss.clients.forEach(client => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(JSON.stringify({ type: 'stock', value: stock }));
                }
            });
        }
    });
});

// Iniciar servidor
server.listen(3001, () => {
    //console.log('Servidor escuchando en http://localhost:3001');
    console.log('Servidor escuchando en http://localhost:3001');
});
